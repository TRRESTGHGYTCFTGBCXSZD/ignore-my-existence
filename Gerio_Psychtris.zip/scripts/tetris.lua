--TETRIIIIIIIIIIIIS!!
--            - english professor
	local frames = 0
	local frameticks = 0
	local tetrisscore = 0
	local tetrislines = 0
	--bit32 = require("bit")
	local downtimereset = 60
	local piecekicks={
	["CW"]={
	[0]={
	{-1,0},{-1,1},{0,-2},{-1,-2},
	},
	[1]={
	{1,0},{1,-1},{0,2},{1,2},
	},
	[2]={
	{1,0},{1,1},{0,-2},{1,-2},
	},
	[3]={
	{-1,0},{-1,-1},{0,2},{-1,2},
	},
	},
	["CCW"]={
	[0]={
	{1,0},{1,1},{0,-2},{1,-2},
	},
	[1]={
	{1,0},{1,-1},{0,2},{1,2},
	},
	[2]={
	{-1,0},{-1,1},{0,-2},{-1,-2},
	},
	[3]={
	{-1,0},{-1,-1},{0,2},{-1,2},
	},
	},
	}
	local ipiecekicks={
	["CW"]={
	[0]={
	{-2,0},{1,0},{-2,-1},{1,2},
	},
	[1]={
	{-1,0},{2,0},{-1,2},{2,-1},
	},
	[2]={
	{2,0},{-1,0},{2,1},{-1,-2},
	},
	[3]={
	{1,0},{-2,0},{1,-2},{-2,1},
	},
	},
	["CCW"]={
	[0]={
	{-1,0},{2,0},{-1,2},{2,-1},
	},
	[1]={
	{2,0},{-1,0},{2,1},{-1,-2},
	},
	[2]={
	{1,0},{-2,0},{1,-2},{-2,1},
	},
	[3]={
	{-2,0},{1,0},{2,1},{-1,-2},
	},
	},
	}
	local piecetype={
	["I"]={
	[0]={
	{0,0,0,0},
	{1,1,1,1},
	{0,0,0,0},
	{0,0,0,0},
	},
	[1]={
	{0,0,1,0},
	{0,0,1,0},
	{0,0,1,0},
	{0,0,1,0},
	},
	[2]={
	{0,0,0,0},
	{0,0,0,0},
	{1,1,1,1},
	{0,0,0,0},
	},
	[3]={
	{0,1,0,0},
	{0,1,0,0},
	{0,1,0,0},
	{0,1,0,0},
	},
	},
	["O"]={
	[0]={
	{0,0,0,0},
	{0,1,1,0},
	{0,1,1,0},
	{0,0,0,0},
	},
	[1]={
	{0,0,0,0},
	{0,1,1,0},
	{0,1,1,0},
	{0,0,0,0},
	},
	[2]={
	{0,0,0,0},
	{0,1,1,0},
	{0,1,1,0},
	{0,0,0,0},
	},
	[3]={
	{0,0,0,0},
	{0,1,1,0},
	{0,1,1,0},
	{0,0,0,0},
	},
	},
	["T"]={
	[0]={
	{0,0,0,0},
	{0,1,0,0},
	{1,1,1,0},
	{0,0,0,0},
	},
	[1]={
	{0,0,0,0},
	{0,1,0,0},
	{0,1,1,0},
	{0,1,0,0},
	},
	[2]={
	{0,0,0,0},
	{0,0,0,0},
	{1,1,1,0},
	{0,1,0,0},
	},
	[3]={
	{0,0,0,0},
	{0,1,0,0},
	{1,1,0,0},
	{0,1,0,0},
	},
	},
	["J"]={
	[0]={
	{0,0,0,0},
	{1,0,0,0},
	{1,1,1,0},
	{0,0,0,0},
	},
	[1]={
	{0,0,0,0},
	{0,1,1,0},
	{0,1,0,0},
	{0,1,0,0},
	},
	[2]={
	{0,0,0,0},
	{0,0,0,0},
	{1,1,1,0},
	{0,0,1,0},
	},
	[3]={
	{0,0,0,0},
	{0,1,0,0},
	{0,1,0,0},
	{1,1,0,0},
	},
	},
	["L"]={
	[0]={
	{0,0,0,0},
	{0,0,1,0},
	{1,1,1,0},
	{0,0,0,0},
	},
	[1]={
	{0,0,0,0},
	{0,1,0,0},
	{0,1,0,0},
	{0,1,1,0},
	},
	[2]={
	{0,0,0,0},
	{0,0,0,0},
	{1,1,1,0},
	{1,0,0,0},
	},
	[3]={
	{0,0,0,0},
	{1,1,0,0},
	{0,1,0,0},
	{0,1,0,0},
	},
	},
	["Z"]={
	[0]={
	{0,0,0,0},
	{1,1,0,0},
	{0,1,1,0},
	{0,0,0,0},
	},
	[1]={
	{0,0,0,0},
	{0,0,1,0},
	{0,1,1,0},
	{0,1,0,0},
	},
	[2]={
	{0,0,0,0},
	{0,0,0,0},
	{1,1,0,0},
	{0,1,1,0},
	},
	[3]={
	{0,0,0,0},
	{0,1,0,0},
	{1,1,0,0},
	{1,0,0,0},
	},
	},
	["S"]={
	[0]={
	{0,0,0,0},
	{0,1,1,0},
	{1,1,0,0},
	{0,0,0,0},
	},
	[1]={
	{0,0,0,0},
	{0,1,0,0},
	{0,1,1,0},
	{0,0,1,0},
	},
	[2]={
	{0,0,0,0},
	{0,0,0,0},
	{0,1,1,0},
	{1,1,0,0},
	},
	[3]={
	{0,0,0,0},
	{1,0,0,0},
	{1,1,0,0},
	{0,1,0,0},
	},
	},
	}
	local tetrion = {}
	local doesitexiststho=
	{
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	{false,false,false,false,false,false,false,false,false,false,},
	}
	local function tablltablltabllcontains(list, x)
		for _, v in pairs(list) do
			if v == x then return true end
		end
		return false
	end
	local function deepCopy(original)
		local copy = {}
		for k, v in pairs(original) do
			if type(v) == "table" then
				v = deepCopy(v)
			end
			copy[k] = v
		end
		return copy
	end
local function collidetest(board,x,y)
	local clipping = false
	if x <= 0 or x >= 11 or (y <= 0 and (x <= 0 or x >= 11)) or y >= 41 then
		clipping = true
	else
		if y >= 1 then
			if board[y][x] ~= "E" then
				clipping = true
			end
		end
	end
	return clipping
end
local function ShuffleInPlace(t)
    for i = #t, 2, -1 do
        local j = math.random(i)
        t[i], t[j] = t[j], t[i]
    end
end
local function sevenbag()
	local bag = {"I","O","T","J","L","Z","S",}
	ShuffleInPlace(bag)
	return bag
end
local function initplayer(player)
	player.board=
	{
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	{"E","E","E","E","E","E","E","E","E","E",},
	}
	player.pieceactive=false
	player.piecex=0
	player.piecey=0
	player.piecerotation=0
	player.piececurrent="E"
	player.piecequeue=sevenbag()
	player.attackincoming=0
	player.linecleartrigger=false
	player.lineclears=0
	player.dead=false
	player.ccwinput=false
	player.ccwlock=false
	player.cwinput=false
	player.cwlock=false
	player.holdinput=false
	player.holdlock=false
	player.holdpiece="E"
	player.tspin="no"
	player.btbs=-1
	player.combo=-1
	player.perfectclear=false
	player.leftinput=false
	player.leftdas=10
	player.rightinput=false
	player.rightdas=10
	player.sdinput=false
	player.hdinput=false
	player.donotnext=false
	player.stillholding=false
	player.amisafe=true
	player.downwardtime=downtimereset
	player.movereset=15
	player.rotreset=15
	player.locktime=30
	player.perfectclearframes=0
end
local function piececollidetest(board,piecetyperr,rotation,x,y)
	clipping = false
	for pies2 = 1 ,4 do
		for pies1 = 1 ,4 do
			if piecetype[piecetyperr][rotation][pies2][pies1] == 1 then
				if collidetest(board,x+pies1-1,y+pies2-1) == true then
					clipping = true
				end
			end
		end
	end
	return clipping
end
local function tspintest(board,rotation,x,y)
	local tspin = "no"
	local tspina = collidetest(board,x,y+1)
	local tspinb = collidetest(board,x+2,y+1)
	local tspinc = collidetest(board,x,y+3)
	local tspind = collidetest(board,x+2,y+3)
	if rotation == 0 or rotation == 2 then
		if tspina and tspinb and (tspinc or tspind) then
			tspin = rotation == 0 and "full" or "mini"
		elseif tspinc and tspind and (tspina or tspinb) then
			tspin = rotation == 2 and "full" or "mini"
		end
	elseif rotation == 1 or rotation == 3 then
		if tspinb and tspind and (tspina or tspinc) then
			tspin = rotation == 1 and "full" or "mini"
		elseif tspina and tspinc and (tspinb or tspind) then
			tspin = rotation == 3 and "full" or "mini"
		end
	end
	return tspin
end
local function modmod(a,b)return a-math.floor(a/b)*b end
local function updateplayer(player)
	player.perfectclearframes=player.perfectclearframes-1
	if player.pieceactive == false and player.dead == false then
		player.pieceactive = true
		if not player.donotnext then
			player.piececurrent = table.remove(player.piecequeue,1)
			if #player.piecequeue < 3 then
				for _, h in pairs(sevenbag()) do
					table.insert(player.piecequeue,h)
				end
			end
		end
		player.piecex = 4
		player.piecey = 17
		player.piecerotation = 0
		player.downwardtime=downtimereset
		player.locktime = 30
		player.movereset = 15
		player.rotreset = 15
		player.ccwlock = false
		player.cwlock = false
		player.holdlock = false
		player.tspin = "no"
		if (player.ccwinput or player.cwinput) and (not(player.ccwinput and player.cwinput)) then
			playSound("prerotate");
		end
		if (player.holdinput or player.stillholding) and (not player.donotnext) then
			playSound("prehold");
		end
		if (player.holdinput or player.stillholding) then
			player.holdlock = true
			player.donotnext = false
			player.stillholding = false
			if player.holdpiece == "E" then
				player.holdpiece = player.piececurrent
				player.piececurrent = table.remove(player.piecequeue,1)
				if #player.piecequeue < 3 then
					for _, h in pairs(sevenbag()) do
						table.insert(player.piecequeue,h)
					end
				end
			else
				player.holdpiece, player.piececurrent = player.piececurrent, player.holdpiece
			end
		end
		if piececollidetest(player.board,player.piececurrent,player.piecerotation,player.piecex,player.piecey) then
			player.dead = true
		end
	end
	if player.pieceactive == true and player.dead == false then
		player.downwardtime=player.downwardtime-1
		if piececollidetest(player.board,player.piececurrent,player.piecerotation,player.piecex,player.piecey+1) then
			player.downwardtime=downtimereset
			player.locktime=player.locktime-1
		else
			player.locktime=30
		end
		if player.sdinput or player.downwardtime <= 0 then
			player.downwardtime=downtimereset
			if player.sdinput then tetrisscore = tetrisscore + 1 end
			player.piecey = player.piecey+1
			if piececollidetest(player.board,player.piececurrent,player.piecerotation,player.piecex,player.piecey) then
				player.piecey = player.piecey-1
				if player.sdinput then tetrisscore = tetrisscore - 1 end
			end
		end
		if not player.ccwinput then
			player.ccwlock = false
		end
		if player.ccwinput and (not player.ccwlock) then
			player.ccwlock = true
			local kicklol = player.piecerotation
			local kicksum = 0
			player.piecerotation = modmod(player.piecerotation-1,4)
			if piececollidetest(player.board,player.piececurrent,player.piecerotation,player.piecex,player.piecey) then
			while piececollidetest(player.board,player.piececurrent,player.piecerotation,player.piecex,player.piecey) do
				kicksum = kicksum + 1
				if kicksum > 4 then
					player.piecerotation = modmod(player.piecerotation+1,4)
				else
					if player.piececurrent == "I" then
						player.piecex = player.piecex+ipiecekicks["CCW"][kicklol][kicksum][1]
						player.piecey = player.piecey-ipiecekicks["CCW"][kicklol][kicksum][2]
						if piececollidetest(player.board,player.piececurrent,player.piecerotation,player.piecex,player.piecey) then
							player.piecex = player.piecex-ipiecekicks["CCW"][kicklol][kicksum][1]
							player.piecey = player.piecey+ipiecekicks["CCW"][kicklol][kicksum][2]
						end
					else
						player.piecex = player.piecex+piecekicks["CCW"][kicklol][kicksum][1]
						player.piecey = player.piecey-piecekicks["CCW"][kicklol][kicksum][2]
						if piececollidetest(player.board,player.piececurrent,player.piecerotation,player.piecex,player.piecey) then
							player.piecex = player.piecex-piecekicks["CCW"][kicklol][kicksum][1]
							player.piecey = player.piecey+piecekicks["CCW"][kicklol][kicksum][2]
						end
					end
				end
			end
			end
			if kicksum <= 4 then
				playSound("rotate");
				if player.piececurrent == "T" then
					player.tspin = tspintest(player.board,player.piecerotation,player.piecex,player.piecey)
					if kicksum == 4 and player.tspin == "mini" then
						player.tspin = "full"
					end
				end
				if player.locktime < 30 then
					player.locktime = 30
					player.rotreset = player.rotreset - 1
				end
			end
		end
		if not player.cwinput then
			player.cwlock = false
		end
		if player.cwinput and (not player.cwlock) then
			player.cwlock = true
			local kicklol = player.piecerotation
			local kicksum = 0
			player.piecerotation = modmod(player.piecerotation+1,4)
			if piececollidetest(player.board,player.piececurrent,player.piecerotation,player.piecex,player.piecey) then
			while piececollidetest(player.board,player.piececurrent,player.piecerotation,player.piecex,player.piecey) do
				kicksum = kicksum + 1
				if kicksum > 4 then
				player.piecerotation = modmod(player.piecerotation-1,4)
				else
					if player.piececurrent == "I" then
						player.piecex = player.piecex+ipiecekicks["CW"][kicklol][kicksum][1]
						player.piecey = player.piecey-ipiecekicks["CW"][kicklol][kicksum][2]
						if piececollidetest(player.board,player.piececurrent,player.piecerotation,player.piecex,player.piecey) then
							player.piecex = player.piecex-ipiecekicks["CW"][kicklol][kicksum][1]
							player.piecey = player.piecey+ipiecekicks["CW"][kicklol][kicksum][2]
						end
					else
						player.piecex = player.piecex+piecekicks["CW"][kicklol][kicksum][1]
						player.piecey = player.piecey-piecekicks["CW"][kicklol][kicksum][2]
						if piececollidetest(player.board,player.piececurrent,player.piecerotation,player.piecex,player.piecey) then
							player.piecex = player.piecex-piecekicks["CW"][kicklol][kicksum][1]
							player.piecey = player.piecey+piecekicks["CW"][kicklol][kicksum][2]
						end
					end
				end
			end
			end
			if kicksum <= 4 then
				playSound("rotate");
				if player.piececurrent == "T" then
					player.tspin = tspintest(player.board,player.piecerotation,player.piecex,player.piecey)
					if kicksum == 4 and player.tspin == "mini" then
						player.tspin = "full"
					end
				end
				if player.locktime < 30 then
					player.locktime = 30
					player.rotreset = player.rotreset - 1
					player.tspin = "no"
				end
			end
		end
		if (not player.leftinput) or (player.leftinput and player.rightinput) then
			player.leftdas = 10
		end
		if player.leftinput and (not(player.leftinput and player.rightinput)) then
			if player.leftdas == 10 or player.leftdas < 0 then
				ishemoving = true
				player.piecex = player.piecex - 1
				if piececollidetest(player.board,player.piececurrent,player.piecerotation,player.piecex,player.piecey) then
					ishemoving = false
					player.piecex = player.piecex + 1
				end
				if player.locktime < 30 and ishemoving then
					player.locktime = 30
					player.movereset = player.movereset - 1
					player.tspin = "no"
				end
			end
			player.leftdas = player.leftdas - 1
		end
		if (not player.rightinput) or (player.leftinput and player.rightinput) then
			player.rightdas = 10
		end
		if player.rightinput and (not(player.leftinput and player.rightinput)) then
			if player.rightdas == 10 or player.rightdas < 0 then
				ishemoving = true
				player.piecex = player.piecex + 1
				if piececollidetest(player.board,player.piececurrent,player.piecerotation,player.piecex,player.piecey) then
					ishemoving = false
					player.piecex = player.piecex - 1
				end
				if player.locktime < 30 and ishemoving then
					player.locktime = 30
					player.movereset = player.movereset - 1
				end
			end
			player.rightdas = player.rightdas - 1
		end
		if player.locktime <= 0 or player.movereset <= 0 or player.rotreset <= 0 and (not (player.hdinput or player.holdinput)) then
			while piececollidetest(player.board,player.piececurrent,player.piecerotation,player.piecex,player.piecey) == false do
				player.piecey = player.piecey+1
			end
			player.piecey = player.piecey-1
			player.pieceactive = false
			player.amisafe = false
			for pies2 = 1 ,4 do
				for pies1 = 1 ,4 do
					if (piecetype[player.piececurrent][player.piecerotation][pies2][pies1] == 1) and (player.piecey+pies2-1 >= 1) then
						player.board[player.piecey+pies2-1][player.piecex+pies1-1] = player.piececurrent
						if player.piecey+pies2 >= 22 then
							player.amisafe = true
						end
					end
				end
			end
			playSound("softlock");
		end
		if player.hdinput then
			while piececollidetest(player.board,player.piececurrent,player.piecerotation,player.piecex,player.piecey) == false do
				player.piecey = player.piecey+1
			end
			player.piecey = player.piecey-1
			player.pieceactive = false
			player.hdinput = false
			player.amisafe = false
			for pies2 = 1 ,4 do
				for pies1 = 1 ,4 do
					if (piecetype[player.piececurrent][player.piecerotation][pies2][pies1] == 1) and (player.piecey+pies2-1 >= 1) then
						player.board[player.piecey+pies2-1][player.piecex+pies1-1] = player.piececurrent
						if player.piecey+pies2 >= 22 then
							player.amisafe = true
						end
					end
				end
			end
			playSound("lock");
		end
		if player.holdinput and (not (player.holdlock or player.hdinput)) then
			player.pieceactive = false
			player.donotnext = true
			player.stillholding = true
		end
	end
	if player.pieceactive == false and (not player.stillholding) and player.dead == false then
		player.linecleartrigger = true
		player.lineclears = 0
		local pccheck = true
		for ita = 1,40 do
			if not tablltablltabllcontains(player.board[ita],"E") then
				table.remove(player.board,ita)
				table.insert(player.board,1,{"E","E","E","E","E","E","E","E","E","E",})
				player.lineclears = player.lineclears + 1
			end
			for ite = 1,10 do
				if player.board[ita][ite] ~= "E" then
					pccheck = false
				end
			end
		end
		player.perfectclear = pccheck
		if pccheck then
			player.perfectclearframes=120
		end
		if player.lineclears > 0 then
			if player.tspin == "full" then
			end
			if player.lineclears == 1 then
			elseif player.lineclears == 2 then
			elseif player.lineclears == 3 then
			elseif player.lineclears == 4 then
			end
			playSound("lineclear");
		end
		if not player.amisafe then
			player.dead = true
			playSound("tetris_dead");
		end
	end
end
function onCreatePost()
	initplayer(tetrion)
    setProperty('botplayTxt.text', "You cant turn on Botplay on Tetris! NO AI TO PLAY! Turn it OFF!")
    makeLuaSprite("tetrion", "tetris-board",getCharacterX("boyfriend"),getCharacterY("boyfriend"))
	addLuaSprite("tetrion", true)
	for i=1,4 do
		for j=1,4 do
			makeAnimatedLuaSprite("tetrionblockactive-"..i.."-"..j, "tetris-block",getCharacterX("boyfriend"),getCharacterY("boyfriend"))
		end
	end
	for i=1,4 do
		for j=2,3 do
			makeAnimatedLuaSprite("tetrionblocknext1-"..i.."-"..j, "tetris-block",getCharacterX("boyfriend"),getCharacterY("boyfriend"))
		end
	end
end
function onUpdate(dt)
frames = frames + (dt*60)
	while frames > 1 do
	frameticks = frameticks + 1
	tetrion.leftinput = keyPressed("left")
	tetrion.sdinput = keyPressed("down")
	tetrion.rightinput = keyPressed("right")
	tetrion.ccwinput = keyPressed("up")
	tetrion.cwinput = keyPressed("space")
	debugPrint(pcall(function()updateplayer(tetrion)
	if tetrion.linecleartrigger then
		tetrion.linecleartrigger = false
		if tetrion.lineclears > 0 then
			tetrion.combo = tetrion.combo + 1
			if tetrion.lineclears >= 4 or tetrion.tspin ~= "no" then
				tetrion.btbs = tetrion.btbs + 1
			else
				tetrion.btbs = -1
			end
			if tetrion.lineclears >= 1 then
				local scoreadd
				if tetrion.lineclears == 1 and tetrion.tspin == "no" then scoreadd = 100 end
				if tetrion.lineclears == 2 and tetrion.tspin == "no" then scoreadd = 300 end
				if tetrion.lineclears == 3 and tetrion.tspin == "no" then scoreadd = 500 end
				if tetrion.lineclears == 4 and tetrion.tspin == "no" then scoreadd = 800 end
				if tetrion.lineclears == 1 and tetrion.tspin == "mini" then scoreadd = 200 end
				if tetrion.lineclears == 2 and tetrion.tspin == "mini" then scoreadd = 400 end
				if tetrion.lineclears == 1 and tetrion.tspin == "full" then scoreadd = 800 end
				if tetrion.lineclears == 2 and tetrion.tspin == "full" then scoreadd = 1200 end
				if tetrion.lineclears == 3 and tetrion.tspin == "full" then scoreadd = 1600 end
				if tetrion.btbs >= 1 then scoreadd = scoreadd * 1.5 end
				tetrisscore = tetrisscore + scoreadd
				tetrislines = tetrislines + tetrion.lineclears
			else
				if tetrion.tspin == "mini" then scoreadd = 100 end
				if tetrion.tspin == "full" then scoreadd = 400 end
				if tetrion.btbs >= 1 then scoreadd = scoreadd * 1.5 end
				tetrisscore = tetrisscore + scoreadd
			end
		else
			tetrion.combo = -1
		end
	end
	end))
	frames = frames - 1
	end
end
local function moveobject(object,x,y)
setProperty(object .. ".x",x)
setProperty(object .. ".y",y)
end
function onUpdatePost()
	setPropertyFromClass('GameOverSubstate', 'characterName', 'tetp_assistant_dead');
	setPropertyFromClass('GameOverSubstate', 'deathSoundName', 'tetris_dead'); --file goes inside sounds/ folder
	setPropertyFromClass('GameOverSubstate', 'loopSoundName', 'continue'); --file goes inside music/ folder
	setPropertyFromClass('GameOverSubstate', 'endSoundName', 'continueyes'); --file goes inside music/ folder
	moveobject("tetrion",getProperty("camFollowPos.x")+150,getProperty("camFollowPos.y")-240)
	for i=1,10 do
		for j=1,40 do
			if tetrion.board[j][i] ~= "E" then
				if not doesitexiststho[j][i] then
				doesitexiststho[j][i] = true
				makeAnimatedLuaSprite("tetrionblock-"..i.."-"..j, "tetris-block",getCharacterX("boyfriend"),getCharacterY("boyfriend"))
				addLuaSprite("tetrionblock-"..i.."-"..j, true)
				end
				moveobject("tetrionblock-"..i.."-"..j,getProperty("camFollowPos.x")+150+8+((i-1)*16),getProperty("camFollowPos.y")-240+384-(16*40)+(j*16))
			else
				if doesitexiststho[j][i] then
				doesitexiststho[j][i] = false
				removeLuaSprite("tetrionblock-"..i.."-"..j, true)
				end
			end
		end
	end
	for i=1,4 do
		for j=1,4 do
			if piecetype[tetrion.piececurrent][tetrion.piecerotation][j][i] == 1 then
				addLuaSprite("tetrionblockactive-"..i.."-"..j, true)
				moveobject("tetrionblockactive-"..i.."-"..j,getProperty("camFollowPos.x")+150+8+((i+tetrion.piecex-2)*16),getProperty("camFollowPos.y")-240+384-(16*40)+((j+tetrion.piecey-1)*16))
			else
				removeLuaSprite("tetrionblockactive-"..i.."-"..j, false)
			end
		end
	end
	for i=1,4 do
		for j=2,3 do
			if piecetype[tetrion.piecequeue[1]][0][j][i] == 1 then
				addLuaSprite("tetrionblocknext1-"..i.."-"..j, true)
				moveobject("tetrionblocknext1-"..i.."-"..j,getProperty("camFollowPos.x")+150+8+((2+i)*16),getProperty("camFollowPos.y")-240+(j*16))
			else
				removeLuaSprite("tetrionblocknext1-"..i.."-"..j, false)
			end
		end
	end
	characterPlayAnim("bf", "hurt", true);
    if tetrion.dead then
        setProperty('health', 0)
	else
        setProperty('health', 3)
    end
	setScore(math.floor(tetrisscore))
	setRatingPercent(tetrislines/100)
	setRatingString("LINES")
end